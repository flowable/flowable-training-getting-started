{
  "key" : "exercise1",
  "name" : "Exercise 1",
  "description" : "",
  "theme" : "theme-1",
  "icon" : "glyphicon-asterisk",
  "usersAccess" : null,
  "groupsAccess" : null,
  "flowApp" : false,
  "url" : null,
  "paletteDefinitionCategory" : "work",
  "extension" : {
    "design" : {
      "childModels" : [ {
        "key" : "exercise1",
        "type" : "bpmn"
      } ]
    }
  }
}