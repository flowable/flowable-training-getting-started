{
  "key" : "exercise7",
  "name" : "Exercise 7: Scooter Company",
  "description" : "",
  "theme" : "theme-1",
  "icon" : "glyphicon-asterisk",
  "usersAccess" : null,
  "groupsAccess" : null,
  "flowApp" : true,
  "url" : null,
  "paletteDefinitionCategory" : "work",
  "pageModels" : [ {
    "key" : "scooterList",
    "name" : "Scooter List",
    "url" : "scooterList",
    "label" : "Scooter List",
    "accessPermissions" : null
  } ],
  "extension" : {
    "design" : {
      "childModels" : [ {
        "key" : "scooter",
        "type" : "cmmn"
      } ]
    }
  }
}