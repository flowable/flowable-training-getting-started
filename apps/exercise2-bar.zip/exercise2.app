{
  "key" : "exercise2",
  "name" : "Exercise 2",
  "description" : "",
  "theme" : "theme-1",
  "icon" : "glyphicon-asterisk",
  "usersAccess" : null,
  "groupsAccess" : null,
  "flowApp" : false,
  "url" : null,
  "paletteDefinitionCategory" : "work",
  "extension" : {
    "design" : {
      "childModels" : [ {
        "key" : "exercise2",
        "type" : "bpmn"
      } ]
    }
  }
}