{
  "key" : "exercise3",
  "name" : "Exercise 3",
  "description" : "",
  "theme" : "theme-1",
  "icon" : "glyphicon-asterisk",
  "usersAccess" : null,
  "groupsAccess" : null,
  "flowApp" : false,
  "url" : null,
  "paletteDefinitionCategory" : "work",
  "extension" : {
    "design" : {
      "childModels" : [ {
        "key" : "exercise3",
        "type" : "bpmn"
      } ]
    }
  }
}